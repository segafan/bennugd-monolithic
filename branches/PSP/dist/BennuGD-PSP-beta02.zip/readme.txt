 BennuGD PSP port - 2nd beta release (15/01/2011)
 ----------------
  
 by danielt3 and josebita
 
 THIS IS A BETA SOFTWARE. IT IS NOT GUARANTED TO WORK IN YOUR SYSTEM.
 
 0. Introduction
 
 This is the second demo of BennuGD running in PSP. The system used is a PSP-3000 with 
 ChickHEN and custom firmware 5.03gen-C. Testing with other systems is greatly welcome.
 
 Project URL is: http://code.google.com/p/bennugd-monolithic
 Check it out for news, info, newer versions and source code.
 
 1. Installation
 
 Just copy the BENNUGD folder to the GAME folder in your homebrew-enabled PSP and run it.
 In this version, BennuGD reads a game called 'game.dcb' which has to be in the
 same folder as the eboot.pbp file.
 
 1.1 Status of the PSP port
 
 Right now, this is a still a beta version and there is a lot to be done. It still crashes
 with several modules. The main testing came from the example dcbs. Of course, testing
 with other games is greatly welcome as well as bug reporting.
 
 DCelso, from the BennuGD forums, has created another monolithic patch. His patch seems
 cleaner than ours and we will try to merge our efforts to create a full featured PSP port.
 
 2. Credits
 
 PSP port of BennuGD: danielt3, josebita
 Demo: josebita
 BennuGD: SplinterGU
 
 3. FAQ
 
 3.1 What is this 'monolithic' name anyway?
 We will write a text in the wiki (check the URL) about this as soon as we get free time.
 But we rather focus on getting the job done for now. Please be patient.
	 
